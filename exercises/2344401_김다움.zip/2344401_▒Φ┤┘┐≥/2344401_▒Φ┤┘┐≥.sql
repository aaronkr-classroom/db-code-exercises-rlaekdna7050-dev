-- DB Final Project Skeleton
-- Student Name: 김다움
-- Student ID: 2344401

-- 1. CREATE TABLE

CREATE TABLE class_code (
    code INT PRIMARY KEY,
    class VARCHAR(20),
    basis VARCHAR(50)
);

CREATE TABLE task_code (
    code INT PRIMARY KEY,
    task VARCHAR(50)
);

-- TODO: customer
-- TODO: staff
-- TODO: tour
-- TODO: reserve

-- 2. INSERT DATA

-- TODO: Insert at least 5 rows into each table

-- 3. INDEX

-- TODO: CREATE INDEX

-- 4. TEST QUERIES

-- Customer Grade Search

-- Employee Task Search

-- Tour Reservation Search

-- Assigned Driver Search

-- INSERT example

-- UPDATE example

-- DELETE example

-- 5. BONUS TABLES (Optional)

-- driver
-- tour_bus
-- assign_driver
-- assign_bus
